# NovaClient 0.2 — Minecraft 1.21.11 Fabric

Original client-side utility project. It is inspired by common client UX patterns but does not copy another client's source.

## Features
- Modern dark Click GUI with tabs
- FPS + Ping HUD
- WASD Keystrokes
- LMB/RMB CPS display
- Toggle sprint
- Hold C to zoom
- Armor HUD with item icons
- JSON config save/load at `config/novaclient.json`
- Right Shift opens GUI

## Default keys
- Right Shift = GUI
- C = Zoom
- R = Sprint

## Build
Use Java 21 and a compatible Gradle installation:

`gradle build`

The JAR is produced in `build/libs/`.

Note: Fabric's newer HUD API has moved toward HudElementRegistry; this project uses the compatible HudRenderCallback for a compact starter implementation.
