package dev.novaclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NovaScreen extends Screen {
    private final Screen parent;
    private int tab = 0;

    public NovaScreen(Screen parent) {
        super(Text.literal("NovaClient"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = width / 2 - 190;
        int top = height / 2 - 125;

        String[] tabs = {"HUD", "Movement", "Utility", "Config"};
        for (int i = 0; i < tabs.length; i++) {
            final int t = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(tabs[i]), b -> {
                tab = t; clearAndInit();
            }).dimensions(left + i * 92, top + 12, 84, 20).build());
        }

        if (tab == 0) {
            toggle(left + 18, top + 55, "FPS / Ping HUD", () -> NovaClient.config.fpsPing,
                    v -> NovaClient.config.fpsPing = v);
            toggle(left + 18, top + 82, "Keystrokes", () -> NovaClient.config.keystrokes,
                    v -> NovaClient.config.keystrokes = v);
            toggle(left + 18, top + 109, "CPS Counter", () -> NovaClient.config.cps,
                    v -> NovaClient.config.cps = v);
            toggle(left + 18, top + 136, "Armor HUD", () -> NovaClient.config.armor,
                    v -> NovaClient.config.armor = v);
        } else if (tab == 1) {
            toggle(left + 18, top + 55, "Sprint", () -> NovaClient.config.sprint,
                    v -> NovaClient.config.sprint = v);
            toggle(left + 18, top + 82, "Zoom", () -> NovaClient.config.zoom,
                    v -> NovaClient.config.zoom = v);
        } else if (tab == 2) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Reset defaults"), b -> {
                NovaClient.config = new Config(); NovaClient.saveConfig(); clearAndInit();
            }).dimensions(left + 18, top + 55, 170, 20).build());
        } else {
            addDrawableChild(ButtonWidget.builder(Text.literal("Save config"), b -> {
                NovaClient.saveConfig(); NovaClient.toast(client, "Configuration saved");
            }).dimensions(left + 18, top + 55, 170, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Reload config"), b -> {
                NovaClient.config = Config.load(NovaClient.configPath);
                NovaClient.toast(client, "Configuration reloaded");
                clearAndInit();
            }).dimensions(left + 18, top + 82, 170, 20).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + 18, top + 170, 170, 20).build());
    }

    private void toggle(int x, int y, String name, java.util.function.BooleanSupplier get,
                        java.util.function.Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(Text.literal(name + ": " + (get.getAsBoolean() ? "ON" : "OFF")), b -> {
            boolean v = !get.getAsBoolean(); set.accept(v);
            b.setMessage(Text.literal(name + ": " + (v ? "ON" : "OFF")));
            NovaClient.saveConfig();
        }).dimensions(x, y, 170, 20).build());
    }

    private void clearAndInit() {
        clearChildren();
        init();
    }

    @Override
    public void close() {
        NovaClient.saveConfig();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public void render(DrawContext d, int mouseX, int mouseY, float delta) {
        renderBackground(d, mouseX, mouseY, delta);
        int left = width / 2 - 190, top = height / 2 - 125;
        d.fill(left, top, left + 382, top + 205, 0xE60B0E16);
        d.fill(left, top, left + 382, top + 3, 0xFF6CD6FF);
        d.drawTextWithShadow(textRenderer, "NovaClient", left + 18, top - 25, 0xFFFFFF);
        d.drawTextWithShadow(textRenderer, "1.21.11 • Client Settings", left + 105, top - 25, 0x8FA5B8);
        super.render(d, mouseX, mouseY, delta);
    }
}
