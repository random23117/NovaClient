package dev.novaclient;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

public final class NovaHud {
    private static long lastLeft;
    private static long lastRight;
    private static int leftCps;
    private static int rightCps;

    private NovaHud() {}

    public static void render(DrawContext d, net.minecraft.client.render.RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || !NovaClient.config.hud) return;

        int x = 8, y = 8;
        if (NovaClient.config.fpsPing) {
            int ping = -1;
            PlayerListEntry e = mc.getNetworkHandler() == null ? null :
                    mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();

            panel(d, x, y, 132, 38);
            d.drawTextWithShadow(mc.textRenderer, "FPS  " + mc.getCurrentFps(), x + 7, y + 6, 0xFFFFFF);
            d.drawTextWithShadow(mc.textRenderer, "PING " + (ping < 0 ? "--" : ping + "ms"), x + 7, y + 20, 0xA9D8FF);
            y += 45;
        }

        if (NovaClient.config.keystrokes) {
            drawKeys(d, mc, mc.getWindow().getScaledWidth() - 92, 8);
        }

        if (NovaClient.config.cps) {
            updateCps(mc);
            panel(d, 8, mc.getWindow().getScaledHeight() - 48, 86, 38);
            d.drawTextWithShadow(mc.textRenderer, "LMB " + leftCps, 15, mc.getWindow().getScaledHeight() - 42, 0xFFFFFF);
            d.drawTextWithShadow(mc.textRenderer, "RMB " + rightCps, 15, mc.getWindow().getScaledHeight() - 27, 0xFFFFFF);
        }

        if (NovaClient.config.armor) drawArmor(d, mc);
    }

    private static void panel(DrawContext d, int x, int y, int w, int h) {
        d.fill(x, y, x + w, y + h, 0xB0101018);
        d.fill(x, y, x + w, y + 1, 0xFF6CD6FF);
    }

    private static void drawKeys(DrawContext d, MinecraftClient mc, int x, int y) {
        String[] keys = {"W", "A", "S", "D"};
        int[] xs = {x + 31, x, x + 31, x + 62};
        int[] ys = {y, y + 23, y + 23, y + 23};
        for (int i = 0; i < 4; i++) {
            boolean pressed = switch (i) {
                case 0 -> mc.options.forwardKey.isPressed();
                case 1 -> mc.options.leftKey.isPressed();
                case 2 -> mc.options.backKey.isPressed();
                default -> mc.options.rightKey.isPressed();
            };
            d.fill(xs[i], ys[i], xs[i] + 28, ys[i] + 20, pressed ? 0xFF4E9CC5 : 0xB0181822);
            d.drawCenteredTextWithShadow(mc.textRenderer, keys[i], xs[i] + 14, ys[i] + 6, 0xFFFFFF);
        }
    }

    private static void updateCps(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS
                && now - lastLeft > 80) {
            leftCps++;
            lastLeft = now;
        }
        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS
                && now - lastRight > 80) {
            rightCps++;
            lastRight = now;
        }
        if (now % 1000 < 55) { leftCps = 0; rightCps = 0; }
    }

    private static void drawArmor(DrawContext d, MinecraftClient mc) {
        int x = mc.getWindow().getScaledWidth() - 180;
        int y = mc.getWindow().getScaledHeight() - 42;
        panel(d, x - 4, y - 4, 164, 38);
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 4; i++) {
            ItemStack stack = inv.getArmorStack(i);
            d.drawItem(stack, x + i * 38, y);
        }
    }
}
