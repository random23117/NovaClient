package dev.novaclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;

public class NovaClient implements ClientModInitializer {
    public static final String MOD_ID = "novaclient";
    public static Config config;
    public static Path configPath;

    public static KeyBinding menuKey;
    public static KeyBinding zoomKey;
    public static KeyBinding sprintKey;

    private static boolean zooming;

    @Override
    public void onInitializeClient() {
        configPath = Path.of("config", "novaclient.json");
        config = Config.load(configPath);

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.novaclient.open_gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.novaclient.zoom", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C, KeyBinding.Category.MISC));
        sprintKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.novaclient.sprint", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R, KeyBinding.Category.MISC));

        HudRenderCallback.EVENT.register(NovaHud::render);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) client.setScreen(new NovaScreen(client.currentScreen));

            boolean z = config.zoom && zoomKey.isPressed();
            if (z != zooming) {
                zooming = z;
                if (client.player != null) {
                    if (z) client.options.getFov().setValue(30);
                    else client.options.getFov().setValue(70);
                }
            }

            if (client.player != null && config.sprint && sprintKey.isPressed()) {
                client.player.setSprinting(true);
            }
        });
    }

    public static void saveConfig() {
        if (config != null) config.save(configPath);
    }

    public static void toast(net.minecraft.client.MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal("§bNovaClient §7» " + message), true);
    }
}
