package dev.novaclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    public boolean hud = true;
    public boolean fpsPing = true;
    public boolean keystrokes = true;
    public boolean cps = true;
    public boolean sprint = false;
    public boolean zoom = true;
    public boolean armor = true;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Config load(Path path) {
        try {
            if (Files.exists(path)) {
                try (Reader r = Files.newBufferedReader(path)) {
                    Config c = GSON.fromJson(r, Config.class);
                    return c == null ? new Config() : c;
                }
            }
        } catch (Exception ignored) {}
        return new Config();
    }

    public void save(Path path) {
        try {
            Files.createDirectories(path.getParent());
            try (Writer w = Files.newBufferedWriter(path)) {
                GSON.toJson(this, w);
            }
        } catch (Exception ignored) {}
    }
}
