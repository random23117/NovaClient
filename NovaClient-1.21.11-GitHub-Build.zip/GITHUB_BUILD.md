# GitHub Build Guide

1. Create a new GitHub repository.
2. Upload all files from this project, including `.github/workflows/build.yml`.
3. Open the **Actions** tab.
4. Select **Build NovaClient**.
5. Press **Run workflow** for a manual build, or push to `main`/`master`.
6. Open the completed workflow run.
7. At the bottom, under **Artifacts**, download **NovaClient-1.21.11**.
8. Extract the downloaded artifact and put the `.jar` in your Minecraft 1.21.11 Fabric `mods` folder.

The workflow builds with Java 21 and uploads the resulting JAR as a GitHub Actions artifact.
